# WordPress MySQL database migration
#
# Generated: Wednesday 3. July 2019 13:45 UTC
# Hostname: localhost
# Database: `university`
# URL: https://github.com/infotush/Fictional-University
# Path: C:\\xampp\\htdocs\\University
# Tables: wp_commentmeta, wp_comments, wp_create_map, wp_group_map, wp_links, wp_map_locations, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, campus, customize_changeset, event, events, homepageslider, like, nav_menu_item, note, page, post, professor, program, sa_slider
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-06-12 14:52:30', '2019-06-12 14:52:30', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_create_map`
#

DROP TABLE IF EXISTS `wp_create_map`;


#
# Table structure of table `wp_create_map`
#

CREATE TABLE `wp_create_map` (
  `map_id` int(11) NOT NULL AUTO_INCREMENT,
  `map_title` varchar(255) DEFAULT NULL,
  `map_width` varchar(255) DEFAULT NULL,
  `map_height` varchar(255) DEFAULT NULL,
  `map_zoom_level` varchar(255) DEFAULT NULL,
  `map_type` varchar(255) DEFAULT NULL,
  `map_scrolling_wheel` varchar(255) DEFAULT NULL,
  `map_visual_refresh` varchar(255) DEFAULT NULL,
  `map_45imagery` varchar(255) DEFAULT NULL,
  `map_street_view_setting` text,
  `map_route_direction_setting` text,
  `map_all_control` text,
  `map_info_window_setting` text,
  `style_google_map` text,
  `map_locations` longtext,
  `map_layer_setting` text,
  `map_polygon_setting` longtext,
  `map_polyline_setting` longtext,
  `map_cluster_setting` text,
  `map_overlay_setting` text,
  `map_geotags` text,
  `map_infowindow_setting` text,
  PRIMARY KEY (`map_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_create_map`
#
INSERT INTO `wp_create_map` ( `map_id`, `map_title`, `map_width`, `map_height`, `map_zoom_level`, `map_type`, `map_scrolling_wheel`, `map_visual_refresh`, `map_45imagery`, `map_street_view_setting`, `map_route_direction_setting`, `map_all_control`, `map_info_window_setting`, `style_google_map`, `map_locations`, `map_layer_setting`, `map_polygon_setting`, `map_polyline_setting`, `map_cluster_setting`, `map_overlay_setting`, `map_geotags`, `map_infowindow_setting`) VALUES
(1, 'Map_location', '962', '402', '4', 'HYBRID', '', NULL, '', 'a:2:{s:11:"pov_heading";s:0:"";s:9:"pov_pitch";s:0:"";}', 'N;', 'a:12:{s:19:"map_center_latitude";s:0:"";s:20:"map_center_longitude";s:0:"";s:21:"zoom_control_position";s:8:"TOP_LEFT";s:18:"zoom_control_style";s:5:"LARGE";s:25:"map_type_control_position";s:9:"TOP_RIGHT";s:22:"map_type_control_style";s:14:"HORIZONTAL_BAR";s:28:"full_screen_control_position";s:9:"TOP_RIGHT";s:28:"street_view_control_position";s:8:"TOP_LEFT";s:18:"infowindow_setting";s:0:"";s:21:"infowindow_openoption";s:5:"click";s:19:"marker_default_icon";s:127:"http:https://github.com/infotush/Fictional-University/wp-content/plugins/wp-google-map-plugin/assets/images//default_marker.png";s:27:"infowindow_bounce_animation";s:0:"";}', 'N;', 'N;', 'a:2:{i:0;s:1:"1";i:1;s:1:"2";}', 'N;', 'N;', NULL, 'N;', 'N;', 'N;', 'N;') ;

#
# End of data contents of table `wp_create_map`
# --------------------------------------------------------



#
# Delete any existing table `wp_group_map`
#

DROP TABLE IF EXISTS `wp_group_map`;


#
# Table structure of table `wp_group_map`
#

CREATE TABLE `wp_group_map` (
  `group_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_map_title` varchar(255) DEFAULT NULL,
  `group_marker` text,
  `extensions_fields` text,
  `group_parent` int(11) DEFAULT '0',
  `group_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_map_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_group_map`
#

#
# End of data contents of table `wp_group_map`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_map_locations`
#

DROP TABLE IF EXISTS `wp_map_locations`;


#
# Table structure of table `wp_map_locations`
#

CREATE TABLE `wp_map_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_title` varchar(255) DEFAULT NULL,
  `location_address` varchar(255) DEFAULT NULL,
  `location_draggable` varchar(255) DEFAULT NULL,
  `location_infowindow_default_open` varchar(255) DEFAULT NULL,
  `location_animation` varchar(255) DEFAULT NULL,
  `location_latitude` varchar(255) DEFAULT NULL,
  `location_longitude` varchar(255) DEFAULT NULL,
  `location_city` varchar(255) DEFAULT NULL,
  `location_state` varchar(255) DEFAULT NULL,
  `location_country` varchar(255) DEFAULT NULL,
  `location_postal_code` varchar(255) DEFAULT NULL,
  `location_zoom` int(11) DEFAULT NULL,
  `location_author` int(11) DEFAULT NULL,
  `location_messages` text,
  `location_settings` text,
  `location_group_map` text,
  `location_extrafields` text,
  PRIMARY KEY (`location_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_map_locations`
#
INSERT INTO `wp_map_locations` ( `location_id`, `location_title`, `location_address`, `location_draggable`, `location_infowindow_default_open`, `location_animation`, `location_latitude`, `location_longitude`, `location_city`, `location_state`, `location_country`, `location_postal_code`, `location_zoom`, `location_author`, `location_messages`, `location_settings`, `location_group_map`, `location_extrafields`) VALUES
(1, 'Tathawade', 'Tathawade, Pimpri-Chinchwad, Maharashtra, India', '', '', 'BOUNCE', '18.626376979327986', '73.7450179312134', 'Pimpri-Chinchwad', 'Maharashtra', 'India', '', 0, NULL, '', 'a:3:{s:7:"onclick";s:6:"marker";s:13:"redirect_link";s:0:"";s:20:"redirect_link_window";s:3:"yes";}', 'N;', NULL),
(2, 'FC Road', 'FC Road, Ganeshwadi, Shivajinagar, Pune, Maharashtra, India', '', '', 'BOUNCE', '18.52048439723157', '73.84068466190183', 'Pune', 'Maharashtra', 'India', '', 0, NULL, '', 'a:3:{s:7:"onclick";s:6:"marker";s:13:"redirect_link";s:0:"";s:20:"redirect_link_window";s:3:"yes";}', 'N;', NULL) ;

#
# End of data contents of table `wp_map_locations`
# --------------------------------------------------------

